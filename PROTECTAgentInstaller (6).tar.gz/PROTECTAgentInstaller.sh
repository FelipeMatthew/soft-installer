#!/bin/sh -e
# ESET PROTECT
# Copyright (c) 1992-2023 ESET, spol. s r.o. All Rights Reserved

cleanup_file="$(mktemp -q)"
finalize()
{
  set +e
  if test -f "$cleanup_file"
  then
    while read f
    do
      rm -f "$f"
    done < "$cleanup_file"
    rm -f "$cleanup_file"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="saasrwpueuhuzh6mljcdhh3mmm.a.ecaserver.eset.com"
eraa_server_port="443"
eraa_server_company_name="Zenklub"
eraa_peer_cert_b64="MIILqgIBAzCCC3AGCSqGSIb3DQEHAaCCC2EEggtdMIILWTCCBfcGCSqGSIb3DQEHBqCCBegwggXkAgEAMIIF3QYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQI0OS1UfhJVaICAggAgIIFsEXPmY46Lqdg303D5r7i7mRLIAqMO4jP9EyM9xG1YNlzCIUFeYeUDCzrQ3LsYmCLuuon4j1ynEHrrv/TKZXwNfjuxgkMCkikQr/xmJsx7cgb82AZPufzb3oXG+JR1ynIGLLfa7Uh6OFtJfOtHcsBfjhIfMwz0Nn107vrHl9q2vO1frh47TDULs8bl6DUA8IQLha8+azREwYeTiv1LsKQ5LMZBG0JLEzU/t6X6FQ6gtfOH6Qk/RwHFscunaAZl6ikJH0x/s5qGbsEOxh/ttEWsAByw/envuWbM0piTwF0OGnZsz2nfGlSAOXBw+ng3ClB1SFKy4OmGS2t7Fy/o9GHJwZhABHr5uxazfcSzwqmQHNBxteIGLJTAADZwxvgaG/8Mmu23E6n98g6ICFUsbMj9HPwgMchjouaD0RlAiIuENENU9lNVm90k70l+Qhre0f0azT8pIDNFdzDTmYKnH0e0PBgLqgUh76VEZDorruxSJekmt1QH1zgmSusVg43EuGAR+BTJ3/FrN/7w/W2lRyuXXJWiq/z2wgeo6D/B163Ty2YLic0qaNTK1YH7z2aaADYK+WaA1AFRg5mGn9gBH9Ui3zfPt8DK+8mqTfyGtT5VasVVsPIXqBJ2mQBJcO3zr9hG1s2B3ahveVoFSaJ1DopMTvU77hXbYVknUIdrFSCmn3WdpcqTZnY2WT/QEvLl1tnYXl2iYoz5/jOifiMlkHy9Gv9omxRj2XgL8Js3t/qljFocEI/3C6FvpGe5ufTPRwShQh5wPMybzwSCdsVVcAa446PCCQUc2Aqv9nO9Z5+iA2IroHE9sDtKHgv31Qtk/f9LxTIAuPovlndoPCjhNmkMTxrGdX/P64avVOJQusntEdoA6awM6+dCOQuDc2Wfs5Vgy11qrO4d8xAr8LXMo99uOyiD2X9obvT6U+MHDmWq0fx/CJt0qMjdNlJo9mw7Jkj4BhO7nzFSBrCQs5UhdvnlJ4bZFFW5Xdsb9EYR5KHygdEX7i1vnzeW78vCIOO+f8/Q25NuwZokaBZgUtjZ9Az15nTgXW6MxZJ83Ao+658eUw4401lyp1Z7z2ngJVCkc7oEJG3PHeT8rzUQeN8McY82V1qutinSu36z4h36jWtDinILQe1BVZausZpsFgqWq25owg6Twe9ascqUAEc9YpIfRJS3ntSKOtOPTsqRj0olWpU9adXwf2ajaB1vsB7//mvuYju4FoARioDXW6/rGrxBBPSvHm9Q4NVTwmC7zvVpH+YPBzRnI3OJ9PPbUf0yFiAXo4AbWcywpnmcJwuYXyRYjjzqKkayy0OzhOrdyYSDiX7usFoy6wB59rRTGJSbknfuq2dGnMCTfdh0gWTQ0UqWzs5We2mlx12wX1X7qJgVm1xbcu1F5Vx5mJTG9Wmw4krrUQLF+TzLw2SusfGwQ28lsoMWs13mpHyMqJMSQve9dL8LPJTB9D2+Ujrh+L8YkNGg/KQu1u3PKMawq7mrRXdFfBNdqn/Lz+jEV3SZ4eEaBhfZZGJCfxFt8UmG900T3zqqtAehrSA3LClj3FeTYjkcUPf+euUYvatLyfD/2a4JurW8/TzAI1p5FgrTEBUpALJ0lGlVto0kPE0bIQEB0l5ZQx0uYVANxTP/1coCmaYZoUxLTMRgFREEobB4dFF3mQcuc1S7KX6GN8+4NSSokXPaG4ToNVPKkRHUlNaqgZ0FFYxEyZ76Gscsl0X7RgZ3WgkVKVgWEbaupQO6yQ6NABG497xMmtCvVhhKgj0e+qWT+h8nUC2YzjQTH/Q70J11JKwK/shgOLvVscs+6AZETwd5w5muVEB/OdlVghh22exErdSvsaYrLTEO9l3/3eN89M85thua4hqzaUfXfWBk+G4Nfegkn6GTTM68iUxtE1Jw54w3NlGCmeAgDnshEWy8/ipk3EXwtpXCuo+iUpGSA53huQwggVaBgkqhkiG9w0BBwGgggVLBIIFRzCCBUMwggU/BgsqhkiG9w0BDAoBAqCCBO4wggTqMBwGCiqGSIb3DQEMAQMwDgQI/Nge6N5vsJcCAggABIIEyOWvyw14ixYNg3NTWYd0pqb/aHQB1x53uvWw+OpyjD/mlukdjO1Enhdq24wWsh3JCPBc/xCfF/+v8d8vweJElocalU2DgFqwEo47xQovgXaxzCxSaz8RZt6vtRGQbKIANb221Wuo3co4Sig0ccFpTGDvCnC+JlTVsdAWXfjz+AdAfe3BqJxJqWzMCw9sqe2Otu58/F5vdtCun3gZiFOaOCs2qiXBT5zbGwqRDfyM3fcB3l60VIZITNpCy45852QWUaV4VX3+NMR1Ld/4zSFAk0rDA9aaeZVPy/5JFO1BcaDd0WBxLvqkMYY4Rv2Kdr3StYarM+fbJqVGsSqZ8QOApfrp6BrnDB2wyi2QuO3DLxgcm3NXdqMAzGS0iLoIYyJ+UkHR3XymqcZDCf8HcVGpVpUHep7o9y80nz0cDgnglQlG+adxv++VH4n3zuFnRUiizAC8WiZp96fRcAmFFrSxBwEFfTtNyNIEzeiVjUWqXIkKhOTCMkucumaRry6Om7M7MTrKRW3BrS0XMM6/NgYk5yVCXOtKrwWC6ln8N6AsDO7zE2kRuFaFDFm2qmWMrriLzzUALakFR/u4+wW4ub+k+VnxwryqAaBpNUiGeZPolVJigx/swRvXXVCkkxFsbrIPW53vvfqz2fgOWHI2RUiX6sP8oq0GGg+jv3c8PFi1niWdc1cdsRCTE7PXVB+rZ5ldk0eB6O0IXFmQKeLen6eFzhUQPDa7+DhVKGRVF9tQrRtywp9ktgW1jjsJ7XUyb8/TB10Iz0pTt1Aw5i2w7FGT15WJyyHXAtyhjnlycei7VvvnAtEQVM3VrRdawK3HX8+8hyX6bwvib4fggiyORW9PihYA67OdX9+EUmWZU03Gjra5TXI7I3ZEMt8ppq9jZ4hZp0wdmAWvxgfUVa40pnqz4rvgs4ed3kjlEfUXpjvb2+oOdI3qs22OSVb9TlpmHflR73W30PNUrg3rmAJ30DnrDxBspdBNEalKliaS0Weav1YL3ahnFaMJCfzHJmc7KuxW7+MGBR9PkUwHPrhCFDOEh3xdKcwdfzPwO3NLj0SBMdf2fnBqqTmJCivDSe64uRp7b1/0vo/vIXyJZIQLc67uVcswp7nFDydSVqhkoD/znUl/xYiVR6NX5gAWav+N4Fc0KoeL1PqksV4L5iXsogQPqs2TJzL4E7hxUZZV0Jl2WjLjZS7dR/lWjCO2f0hHANSDI4xFHVI+xXc8Umu5gBtwby5jko3sFQl2pzn9F3lLFqCYSedYMhaFIXkmAJ/+fEO0Gs4V97qMnVc0A7SElJnqiypnG8MWtnbt9aQVHe06nKIIsiItyrK0CXTP6geJ92k0CTtg6vp/z5q1bUFkTdi5gV1I+ueTnT7A781WHRU+DBHQU5UqsrLxR0EfppkjIqDEO4ilPGoPaU1z6IlNcR9P9RkLcwyremjwFtLZ+cASz1KPF9EB1fLDgVuEoXKVUmDvywca+FMGNoVxkTKtBTnrb5Sbj9/Q6FMll74zezgacyar7kB+wX7lR1JQIYS/wWPAZzycK7Ox++3FYzVndGGz9ZOeaUg4gw6fcrzbQ2EXAd8mmuC5ESZ9+uptd98mvrUsR5olIpoyLxCtAPoO5HmxpYAAnMEJukjaHTE+MBcGCSqGSIb3DQEJFDEKHggARQBTAEUAVDAjBgkqhkiG9w0BCRUxFgQUJUcWQRsZNCdyLrr5huyZf085BtUwMTAhMAkGBSsOAwIaBQAEFPrSadltmYH9JDGgJwXB40dEAoyNBAj1RzAkF3swJwICCAA="
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIFpDCCA4ygAwIBAgIIMUSW0eFkh/8wDQYJKoZIhvcNAQELBQAwaDELMAkGA1UEBhMCU0sxGDAWBgNVBAgTD1Nsb3ZhayBSZXB1YmxpYzETMBEGA1UEBxMKQnJhdGlzbGF2YTENMAsGA1UEChMERXNldDEbMBkGA1UEAxMSRVBDIEFnZW50IHByb3h5IENBMB4XDTIyMDYyMDAwMDAwMFoXDTMyMDYxOTIzNTk1OVowaDELMAkGA1UEBhMCU0sxGDAWBgNVBAgTD1Nsb3ZhayBSZXB1YmxpYzETMBEGA1UEBxMKQnJhdGlzbGF2YTENMAsGA1UEChMERXNldDEbMBkGA1UEAxMSRVBDIEFnZW50IHByb3h5IENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApFyygZ31hn6s/K7+Lm/r3KP+P5Gn0pb5J6IR0F+KtBUiNE9nRn5PnVDdyj9uVd6BZIKcczoHebH/70GQUuOzprDtHhWUTNDZ7R4NfNz0u5cYn2mKPk9lJRPEcuvqKr+aGsCs1yMv226xd72ngJE/Z2MlGLGX5+kuO0HmQWRUK/SDtmcCvforHs7zE19PjXmZQnpW+bUFkLeHcHS4WtJ64CNkbuTHssK8nNDQoJXLZVKafLWCkAZ94vpZWDRG5AffdBDnKrSy+WOTI6dOJw8i+uJ7YtWconTJo9NRCcgTzCHujylXgqWkwm3f+Wh/h0u5KIJEzTPN/RTzP+/SWEDrYi7+wECXWv6kU3Ty3KkzPGsAt9ABmnvAUGShi8Heyhnes6E3IiUt3wko+LHVw9hFyXFjfqtgRtxvOTcX06zinpQbtl+d1Wm7mU/ORFIPffRec4B9YewF1VRCm4gT5vqFZbO7BUnuyKFeGr6Vxlgrgz0mPS0PAoATI500x9g8Md3Mmshc/6wLInMHgSh//n+aylnePRrTvLEJhcWgoDx57wZ7G5fTeHEFIRrcU3ez6PSKbodCBcjfWrGLkXNQzmIwhDxVRmo4DXLga6MzbYqU54zQVfk60CiFEvwwK8l7WBZ7XlqxRl8QmsIUGf278N8Hxe0qOs7fcZPvuVHyhS4WKxsCAwEAAaNSMFAwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUZ9DJSflsyGkpLas5Ll3dMzeMJSEwCwYDVR0PBAQDAgEGMBEGCWCGSAGG+EIBAQQEAwIABzANBgkqhkiG9w0BAQsFAAOCAgEAWrXSFAd4OmT0bxHj1q+zMROTxXalzfAfqncTGaTm2NiqL5be3WfgnQLjGOMX+VVC1YXDlI2xs2JAWD3myRT4u7g1Y320HmjWczaE36h8PrnL+M/LEIHem3bM7e6ZFGHzwN80D5bmM++qacrGnnSDXid/sVx2Vi5KKXOXcFB74Haef5mqVm9uNpjDuUO+7Zdip6xqieHOpYD7HIWCkq/bJXxyrPr9CY37KyVdeMoU8QuIzdlgn5l0yc8LNBXXv7pba+ykPirIWe1ZR0O0z5e0gAqUe0kz9fpiMmzWpaGS/4s8gt0oYX2Ahibc3Lgg179OOpUFOsz92TmPVQCnzseZCPirikCA7qUAmMFKqs+l+X6DdKIrL4ocHs5zFAL9fysdKpczKczAWpZXr9LtuY6WFDkcWhxm4kj1MXyte8UBBC4C1UX47Km5TlOQUApnp7LMXI3jlBB+2Lo3T9N2FhiQ5R2PoNdA+XONNaBb8E9mh83wOvA6+Me1Rb7bIO6q/dTULd41Jns3JQ8zy0H8rQrOSOREWfieW0Czd38ZRJoa7MRp6Z3aYAuqt8pJpOykVbKQY/OYh43pt5gfgFvIkI3CuoJvLPQ3bYKyBiJN8PYhFpOyLYOrOJqbd26x+QFORgiBdZo6u6Em31l3fVpiaMcSAD9Cny6VUEC2aYn00beB2Vc="
eraa_product_uuid=""
eraa_initial_sg_token="MDAwMDAwMDAtMDAwMC0wMDAwLTcwMDEtMDAwMDAwMDAwMDAxzmPOst9oRqWmnjE9ybCnQFOIOvU8kU1bnKwqpf2GU69Kkb/qCJl+ri813dlsfbPy7SZ1Dw=="
eraa_policy_data=""

arch=$(uname -m)
eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v10/10.1.2272.0/agent_linux_i386.sh"
eraa_installer_checksum="cccc7ad9ece96e9c1c5ffb05ae7f07fcbd1f4a25b34af52ba1fe34f38820b6d7"

if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 > /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v10/10.1.2272.0/agent_linux_x86_64.sh"
    eraa_installer_checksum="37b2f23bb69f3572d8f17c909c6fa920b4e769eb95772e38c5badcad77fd2664"
fi

echo "ESET Management Agent live installer script. Copyright © 1992-2023 ESET, spol. s r.o. - All rights reserved."

if test ! -z $eraa_server_company_name
then
  echo " * CompanyName: $eraa_server_company_name"
fi
echo " * Hostname: $eraa_server_hostname"
echo " * Port: $eraa_server_port"
echo " * Installer: $eraa_installer_url"
echo

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture."
  exit 1
fi

local_cert_path="$(mktemp -q -u)"
echo $eraa_peer_cert_b64 | base64 -d > "$local_cert_path" && echo "$local_cert_path" >> "$cleanup_file"

if test -n "$eraa_ca_cert_b64"
then
  local_ca_path="$(mktemp -q -u)"
  echo $eraa_ca_cert_b64 | base64 -d > "$local_ca_path" && echo "$local_ca_path" >> "$cleanup_file"
fi


eraa_http_proxy_value=""

local_installer="$(dirname $0)"/"$(basename $eraa_installer_url)"

if $(echo "$eraa_installer_checksum  $local_installer" | sha256sum -c 2> /dev/null > /dev/null)
then
    echo "Verified local installer was found: '$local_installer'"
else
    local_installer="$(mktemp -q -u)"

    echo "Downloading ESET Management Agent installer..."

    if test -n "$eraa_http_proxy_value"
    then
      export use_proxy=yes
      export http_proxy="$eraa_http_proxy_value"
      (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || wget --connect-timeout 300 --no-proxy --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
    else
      (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
    fi

    if test ! -s "$local_installer"
    then
       echo "Failed to download installer file"
       exit 2
    fi

    echo -n "Checking integrity of installer script " && echo "$eraa_installer_checksum  $local_installer" | sha256sum -c
fi

chmod +x "$local_installer"

command -v sudo > /dev/null && usesudo="sudo -E" || usesudo=""

export _ERAAGENT_PEER_CERT_PASSWORD="$eraa_peer_cert_pwd"

echo
echo Running installer script $local_installer
echo

$usesudo /bin/sh "$local_installer"\
   --skip-license \
   --hostname "$eraa_server_hostname"\
   --port "$eraa_server_port"\
   --cert-path "$local_cert_path"\
   --cert-password "env:_ERAAGENT_PEER_CERT_PASSWORD"\
   --cert-password-is-base64\
   --initial-static-group "$eraa_initial_sg_token"\
   \
   --disable-imp-program\
   $(test -n "$local_ca_path" && echo --cert-auth-path "$local_ca_path")\
   $(test -n "$eraa_product_uuid" && echo --product-guid "$eraa_product_uuid")\
   $(test -n "$eraa_policy_data" && echo --custom-policy "$eraa_policy_data")
